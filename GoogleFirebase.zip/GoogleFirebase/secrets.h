#define SECRET_SSID "WestBoyer" //Pulled from the "secrets.h notepad file stored in the same directory as the "WiFi Client ThingSpeak Lab" file.
#define SECRET_PASS "West@7559"
#define FIREBASE_HOST "https://fir-iot-application-default-rtdb.firebaseio.com" //Firebase URL.
#define FIREBASE_AUTH "lWCiBJrKNIEtWXYannqX4Q0ykmWYJYx3nfPzdHdS" //Pulled from Firebase's database secrets.
